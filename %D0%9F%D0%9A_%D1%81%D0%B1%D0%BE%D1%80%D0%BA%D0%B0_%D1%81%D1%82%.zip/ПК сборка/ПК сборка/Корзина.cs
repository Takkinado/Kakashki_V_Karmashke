﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ПК_сборка
{
    // Не хватает комплектующего на складе
    public class НетНаСкладе : Exception
    {
        public НетНаСкладе(string название) : base(название) { }
    }

    public partial class Корзина : Form
    {
        private Database31DataSet database31DataSet = new Database31DataSet();
        private Database31DataSetTableAdapters.КомплектующиеTableAdapter комплектующиеTableAdapter = new Database31DataSetTableAdapters.КомплектующиеTableAdapter();

        public Корзина()
        {
            InitializeComponent();
        }

        private void Корзина_Load(object sender, EventArgs e)
        {
            this.комплектующиеTableAdapter.Fill(this.database31DataSet.Комплектующие);
            Сессия.ЗагрузитьОстатки(this.database31DataSet.Комплектующие);
            this.dataGridView1.DataSource = this.database31DataSet.Комплектующие;
            this.dataGridView2.DataSource = Сессия.ПозицииКорзины;

            // Обычному покупателю не показываем служебные идентификаторы.
            СкрытьСлужебныеСтолбцы(this.dataGridView1);
            СкрытьСлужебныеСтолбцы(this.dataGridView2);

            ОбновитьИтого();
        }

        private static void СкрытьСлужебныеСтолбцы(DataGridView таблица)
        {
            foreach (DataGridViewColumn столбец in таблица.Columns)
            {
                string имя = столбец.Name.ToLowerInvariant();
                string заголовок = (столбец.HeaderText ?? "").ToLowerInvariant();

                if (имя.StartsWith("id_") || имя.StartsWith("id") ||
                    имя.Contains("конфигурац") || заголовок.StartsWith("id") ||
                    заголовок.Contains("идентификатор") || заголовок.Contains("конфигурац"))
                {
                    столбец.Visible = false;
                }
            }
        }

        private void ОбновитьИтого()
        {
            decimal итого = Сессия.ПозицииКорзины.Sum(p => p.Сумма);
            this.label3.Text = "итого: " + итого.ToString("N2");
        }

        // Добавить в корзину
        private void button1_Click(object sender, EventArgs e)
        {
            DataRowView строка = this.dataGridView1.CurrentRow == null ? null : this.dataGridView1.CurrentRow.DataBoundItem as DataRowView;
            if (строка == null)
            {
                MessageBox.Show("Выберите комплектующее в списке.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int id = Convert.ToInt32(строка["Id_Комплектующего"]);
            int остаток = строка["Количество"] == DBNull.Value ? 0 : Convert.ToInt32(строка["Количество"]);
            ПозицияКорзины позиция = Сессия.ПозицииКорзины.FirstOrDefault(p => p.Id_Комплектующего == id);

            int вКорзине = позиция == null ? 0 : позиция.Количество;
            if (вКорзине + 1 > остаток)
            {
                MessageBox.Show("Нет в наличии. Остаток на складе: " + остаток + ".", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (позиция != null)
            {
                позиция.Количество++;
                Сессия.ПозицииКорзины.ResetBindings();
            }
            else
            {
                Сессия.ПозицииКорзины.Add(new ПозицияКорзины
                {
                    Id_Комплектующего = id,
                    Название_Детали = Convert.ToString(строка["Название_Детали"]),
                    Цена = строка["Цена"] == DBNull.Value ? 0m : Convert.ToDecimal(строка["Цена"]),
                    Количество = 1
                });
            }
            ОбновитьИтого();
        }

        // Удалить из корзины
        private void button2_Click(object sender, EventArgs e)
        {
            ПозицияКорзины позиция = this.dataGridView2.CurrentRow == null ? null : this.dataGridView2.CurrentRow.DataBoundItem as ПозицияКорзины;
            if (позиция == null)
            {
                MessageBox.Show("Выберите позицию в корзине.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            // убираем одну штуку, а когда штук не осталось - всю позицию
            if (позиция.Количество > 1)
            {
                позиция.Количество--;
                Сессия.ПозицииКорзины.ResetBindings();
            }
            else
            {
                Сессия.ПозицииКорзины.Remove(позиция);
            }
            ОбновитьИтого();
        }

        // Удалить позицию целиком
        private void button4_Click(object sender, EventArgs e)
        {
            ПозицияКорзины позиция = this.dataGridView2.CurrentRow == null ? null : this.dataGridView2.CurrentRow.DataBoundItem as ПозицияКорзины;
            if (позиция == null)
            {
                MessageBox.Show("Выберите позицию в корзине.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            Сессия.ПозицииКорзины.Remove(позиция);
            ОбновитьИтого();
        }

        private static int Скаляр(OleDbConnection conn, string sql)
        {
            using (OleDbCommand cmd = new OleDbCommand(sql, conn))
            {
                object результат = cmd.ExecuteScalar();
                return (результат == null || результат == DBNull.Value) ? 0 : Convert.ToInt32(результат);
            }
        }

        // Оформить заказ
        private void button3_Click(object sender, EventArgs e)
        {
            if (Сессия.ПозицииКорзины.Count == 0)
            {
                MessageBox.Show("Корзина пуста.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                int позиций = Сессия.ПозицииКорзины.Count;
                decimal сумма = Сессия.ПозицииКорзины.Sum(p => p.Сумма);
                int idКонфигурации;

                using (OleDbConnection conn = new OleDbConnection(Сессия.СтрокаПодключения))
                {
                    conn.Open();

                    int idМенеджера = Скаляр(conn, "SELECT MIN(Id_Менеджера) FROM Менеджеры");
                    int idСборщика = Скаляр(conn, "SELECT MIN(Id_Сборщика) FROM Сборщики");
                    int idДоставки = Скаляр(conn, "SELECT MIN(Id_Доставки) FROM [Служба Доставки]");
                    if (idМенеджера == 0 || idСборщика == 0 || idДоставки == 0)
                    {
                        MessageBox.Show("Для оформления заказа нужны записи в таблицах Менеджеры, Сборщики и Служба Доставки.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    idКонфигурации = Math.Max(
                        Скаляр(conn, "SELECT MAX(ID_Конфигурации) FROM [Состав конфига]"),
                        Скаляр(conn, "SELECT MAX(ID_Конфигурации) FROM Заказы")) + 1;

                    using (OleDbTransaction транзакция = conn.BeginTransaction())
                    {
                        try
                        {
                            // все позиции корзины попадают в состав одного заказа
                            foreach (ПозицияКорзины p in Сессия.ПозицииКорзины)
                            {
                                using (OleDbCommand cmd = new OleDbCommand("INSERT INTO [Состав конфига] (ID_Конфигурации, ID_Комплектующего, Количество) VALUES (?, ?, ?)", conn, транзакция))
                                {
                                    cmd.Parameters.Add("ID_Конфигурации", OleDbType.Integer).Value = idКонфигурации;
                                    cmd.Parameters.Add("ID_Комплектующего", OleDbType.Integer).Value = p.Id_Комплектующего;
                                    cmd.Parameters.Add("Количество", OleDbType.Integer).Value = p.Количество;
                                    cmd.ExecuteNonQuery();
                                }

                                // списываем купленное количество со склада
                                using (OleDbCommand cmd = new OleDbCommand("UPDATE Комплектующие SET Количество = Количество - ? WHERE Id_Комплектующего = ? AND Количество >= ?", conn, транзакция))
                                {
                                    cmd.Parameters.Add("Количество", OleDbType.Integer).Value = p.Количество;
                                    cmd.Parameters.Add("Id_Комплектующего", OleDbType.Integer).Value = p.Id_Комплектующего;
                                    cmd.Parameters.Add("Остаток", OleDbType.Integer).Value = p.Количество;
                                    if (cmd.ExecuteNonQuery() == 0)
                                        throw new НетНаСкладе(p.Название_Детали);
                                }
                            }

                            using (OleDbCommand cmd = new OleDbCommand("INSERT INTO Заказы (ID_Конфигурации, ID_Покупателя, ID_Менеджера, ID_Сборщика, ID_Доставки, Дата_создания, Итоговая_Стоимость, Статус) VALUES (?, ?, ?, ?, ?, ?, ?, ?)", conn, транзакция))
                            {
                                cmd.Parameters.Add("ID_Конфигурации", OleDbType.Integer).Value = idКонфигурации;
                                cmd.Parameters.Add("ID_Покупателя", OleDbType.Integer).Value = Сессия.ID_Покупателя;
                                cmd.Parameters.Add("ID_Менеджера", OleDbType.Integer).Value = idМенеджера;
                                cmd.Parameters.Add("ID_Сборщика", OleDbType.Integer).Value = idСборщика;
                                cmd.Parameters.Add("ID_Доставки", OleDbType.Integer).Value = idДоставки;
                                cmd.Parameters.Add("Дата_создания", OleDbType.Date).Value = DateTime.Now;
                                cmd.Parameters.Add("Итоговая_Стоимость", OleDbType.Currency).Value = сумма;
                                cmd.Parameters.Add("Статус", OleDbType.VarWChar).Value = "Новый";
                                cmd.ExecuteNonQuery();
                            }

                            транзакция.Commit();
                        }
                        catch
                        {
                            транзакция.Rollback();
                            throw;
                        }
                    }
                }

                Сессия.ПозицииКорзины.Clear();
                ОбновитьИтого();

                // обновляем остатки в списке комплектующих
                this.комплектующиеTableAdapter.Fill(this.database31DataSet.Комплектующие);
                Сессия.ЗагрузитьОстатки(this.database31DataSet.Комплектующие);

                DateTime примернаяДатаДоставки = DateTime.Now.AddDays(7);
                MessageBox.Show(
                    $"Заказ успешно оформлен!\\nПозиций: {позиций}.\\nИтого: {сумма:N2}\\n\\nОриентировочная дата доставки: {примернаяДатаДоставки:dd.MM.yyyy}.\\nСрок примерный и может измениться.",
                    "Заказ оформлен", MessageBoxButtons.OK, MessageBoxIcon.Information);
                var mainForm = Application.OpenForms.OfType<Form1>().FirstOrDefault();
                if (mainForm != null) mainForm.RefreshAllTables();
            }
            catch (НетНаСкладе ex)
            {
                MessageBox.Show("Недостаточно на складе: " + ex.Message + ". Уменьшите количество в корзине.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при оформлении заказа: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
