﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ПК_сборка
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Expose DataSet and TableAdapters for other forms to use the same connection/instance
        public Database31DataSet DatabaseInstance => this.database31DataSet;
        public Database31DataSetTableAdapters.МенеджерыTableAdapter МенеджерыAdapter => this.менеджерыTableAdapter;
        public Database31DataSetTableAdapters.ПокупателиTableAdapter ПокупателиAdapter => this.покупателиTableAdapter;
        public Database31DataSetTableAdapters.КомплектующиеTableAdapter КомплектующиеAdapter => this.комплектующиеTableAdapter;
        public Database31DataSetTableAdapters.СборщикиTableAdapter СборщикиAdapter => this.сборщикиTableAdapter;
        public Database31DataSetTableAdapters.Служба_ДоставкиTableAdapter СлужбаДоставкиAdapter => this.служба_ДоставкиTableAdapter;
        public Database31DataSetTableAdapters.Состав_конфигаTableAdapter СоставКонфигаAdapter => this.состав_конфигаTableAdapter;
        public Database31DataSetTableAdapters.ЗаказыTableAdapter ЗаказыAdapter => this.заказыTableAdapter;

        private void Form1_Load(object sender, EventArgs e)
        {
            // Администратор не покупатель - корзина ему не нужна
            this.корзинаToolStripMenuItem.Visible = !Сессия.ЭтоАдмин;

            // Покупатель: нет добавления записей, видит только комплектующие и свои заказы
            if (!Сессия.ЭтоАдмин)
            {
                this.добавитьToolStripMenuItem.Visible = false;
                this.сборщикиToolStripMenuItem.Visible = false;       // Покупатели
                this.менеджерыToolStripMenuItem1.Visible = false;     // Менеджеры
                this.службаДоставкиToolStripMenuItem.Visible = false; // Сборщики
                this.заказыToolStripMenuItem.Visible = false;         // Служба Доставки
                this.составКонфигаToolStripMenuItem.Visible = false;  // Состав Конфига
                this.заказыBindingSource.Filter = "ID_Покупателя = " + Сессия.ID_Покупателя;

                // при входе покупателя сразу показываем таблицу «Комплектующие»
                покупателиToolStripMenuItem_Click(null, null);
            }

            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;

            // TODO: данная строка кода позволяет загрузить данные в таблицу "database31DataSet.Состав_конфига". При необходимости она может быть перемещена или удалена.
            this.состав_конфигаTableAdapter.Fill(this.database31DataSet.Состав_конфига);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "database31DataSet.Служба_Доставки". При необходимости она может быть перемещена или удалена.
            this.служба_ДоставкиTableAdapter.Fill(this.database31DataSet.Служба_Доставки);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "database31DataSet.Сборщики". При необходимости она может быть перемещена или удалена.
            this.сборщикиTableAdapter.Fill(this.database31DataSet.Сборщики);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "database31DataSet.Покупатели". При необходимости она может быть перемещена или удалена.
            this.покупателиTableAdapter.Fill(this.database31DataSet.Покупатели);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "database31DataSet.Менеджеры". При необходимости она может быть перемещена или удалена.
            this.менеджерыTableAdapter.Fill(this.database31DataSet.Менеджеры);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "database31DataSet.Комплектующие". При необходимости она может быть перемещена или удалена.
            this.комплектующиеTableAdapter.Fill(this.database31DataSet.Комплектующие);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "database31DataSet.Заказы". При необходимости она может быть перемещена или удалена.
            this.заказыTableAdapter.Fill(this.database31DataSet.Заказы);

            // Для администратора заменяем обычную ячейку статуса на выпадающий список.
            // Остальные поля заказа остаются только для чтения.
            if (Сессия.ЭтоАдмин)
            {
                int индексСтатуса = this.dataGridView1.Columns
                    .IndexOf(this.статусDataGridViewTextBoxColumn);
                this.dataGridView1.Columns.Remove(this.статусDataGridViewTextBoxColumn);

                DataGridViewComboBoxColumn колонкаСтатуса = new DataGridViewComboBoxColumn();
                колонкаСтатуса.Name = "статусComboBoxColumn";
                колонкаСтатуса.HeaderText = "Статус заказа";
                колонкаСтатуса.DataPropertyName = "Статус";
                колонкаСтатуса.ValueType = typeof(string);
                колонкаСтатуса.DisplayStyle = DataGridViewComboBoxDisplayStyle.DropDownButton;
                колонкаСтатуса.FlatStyle = FlatStyle.Flat;

                string[] статусы = {
                    "Новый", "В обработке", "Собирается",
                    "Готов к отправке", "В пути", "Доставлен", "Отменён"
                };
                foreach (string значение in статусы)
                    колонкаСтатуса.Items.Add(значение);

                // Добавляем в список старые статусы, если они уже есть в базе.
                foreach (DataRow заказ in this.database31DataSet.Заказы.Rows)
                {
                    string текущийСтатус = Convert.ToString(заказ["Статус"]);
                    if (!string.IsNullOrWhiteSpace(текущийСтатус) &&
                        !колонкаСтатуса.Items.Contains(текущийСтатус))
                        колонкаСтатуса.Items.Add(текущийСтатус);
                }

                this.dataGridView1.Columns.Insert(индексСтатуса, колонкаСтатуса);
                this.dataGridView1.ReadOnly = false;
                foreach (DataGridViewColumn колонка in this.dataGridView1.Columns)
                    колонка.ReadOnly = true;
                колонкаСтатуса.ReadOnly = false;
                this.dataGridView1.CellEndEdit += dataGridView1_CellEndEdit;
                this.dataGridView1.DataError += dataGridView1_DataError;
            }
            else
            {
                this.dataGridView1.ReadOnly = true;
            }

            // Остаток комплектующих
            Сессия.ЗагрузитьОстатки(this.database31DataSet.Комплектующие);
            DataGridViewTextBoxColumn колонкаКоличество = new DataGridViewTextBoxColumn();
            колонкаКоличество.Name = "колонкаКоличество";
            колонкаКоличество.HeaderText = "Количество";
            колонкаКоличество.DataPropertyName = "Количество";
            this.dataGridView2.Columns.Add(колонкаКоличество);
        }

        private void dataGridView1_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            // Не показываем стандартное окно DataGridView при некорректном значении списка.
            e.ThrowException = false;
        }

        // Сохранение выбранного статуса заказа (только администратор).
        private void dataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (!Сессия.ЭтоАдмин || e.RowIndex < 0 ||
                dataGridView1.Columns[e.ColumnIndex].DataPropertyName != "Статус")
                return;

            DataRowView строка = dataGridView1.Rows[e.RowIndex].DataBoundItem as DataRowView;
            if (строка == null) return;

            string статус = Convert.ToString(строка["Статус"]).Trim();
            string[] допустимыеСтатусы = {
                "Новый", "В обработке", "Собирается",
                "Готов к отправке", "В пути", "Доставлен", "Отменён"
            };

            if (!допустимыеСтатусы.Contains(статус))
            {
                MessageBox.Show("Выберите статус: " + string.Join(", ", допустимыеСтатусы),
                    "Некорректный статус", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                RefreshAllTables();
                return;
            }

            try
            {
                int idКонфигурации = Convert.ToInt32(строка["ID_Конфигурации"]);
                using (OleDbConnection conn = new OleDbConnection(Сессия.СтрокаПодключения))
                using (OleDbCommand cmd = new OleDbCommand(
                    "UPDATE Заказы SET Статус = ? WHERE ID_Конфигурации = ?", conn))
                {
                    cmd.Parameters.Add("Статус", OleDbType.VarWChar).Value = статус;
                    cmd.Parameters.Add("ID_Конфигурации", OleDbType.Integer).Value = idКонфигурации;
                    conn.Open();
                    if (cmd.ExecuteNonQuery() == 0)
                        throw new Exception("Заказ не найден в базе данных.");
                }
                this.заказыTableAdapter.Fill(this.database31DataSet.Заказы);
                MessageBox.Show("Статус заказа обновлён.", "Успех",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось изменить статус: " + ex.Message,
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                RefreshAllTables();
            }
        }

        // Обновить все таблицы на главной форме
        public void RefreshAllTables()
        {
            this.состав_конфигаTableAdapter.Fill(this.database31DataSet.Состав_конфига);
            this.служба_ДоставкиTableAdapter.Fill(this.database31DataSet.Служба_Доставки);
            this.сборщикиTableAdapter.Fill(this.database31DataSet.Сборщики);
            this.покупателиTableAdapter.Fill(this.database31DataSet.Покупатели);
            this.менеджерыTableAdapter.Fill(this.database31DataSet.Менеджеры);
            this.комплектующиеTableAdapter.Fill(this.database31DataSet.Комплектующие);
            this.заказыTableAdapter.Fill(this.database31DataSet.Заказы);
            Сессия.ЗагрузитьОстатки(this.database31DataSet.Комплектующие);
        }

        private void комплектующиеToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
             Close(); 
        }

        private void менеджерыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGridView1.Visible = true;
            dataGridView2.Visible = false;
            dataGridView3.Visible = false;
            dataGridView4.Visible = false;
            dataGridView5.Visible = false;
            dataGridView6.Visible = false;
            dataGridView7.Visible = false;

        }

        private void покупателиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGridView1.Visible = false;
            dataGridView2.Visible = true;
            dataGridView3.Visible = false;
            dataGridView4.Visible = false;
            dataGridView5.Visible = false;
            dataGridView6.Visible = false;
            dataGridView7.Visible = false;
        }

        private void сборщикиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGridView1.Visible = false;
            dataGridView2.Visible = false;
            dataGridView3.Visible = false;
            dataGridView4.Visible = true;
            dataGridView5.Visible = false;
            dataGridView6.Visible = false;
            dataGridView7.Visible = false;
        }

        private void службаДоставкиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGridView1.Visible = false;
            dataGridView2.Visible = false;
            dataGridView3.Visible = false;
            dataGridView4.Visible = false;
            dataGridView5.Visible = true;
            dataGridView6.Visible = false;
            dataGridView7.Visible = false;
        }

        private void заказыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGridView1.Visible = false;
            dataGridView2.Visible = false;
            dataGridView3.Visible = false;
            dataGridView4.Visible = false;
            dataGridView5.Visible = false;
            dataGridView6.Visible = true;
            dataGridView7.Visible = false;
        }

        private void менеджерыToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            dataGridView1.Visible = false;
            dataGridView2.Visible = false;
            dataGridView3.Visible = true;
            dataGridView4.Visible = false;
            dataGridView5.Visible = false;
            dataGridView6.Visible = false;
            dataGridView7.Visible = false;
        }

        private void составКонфигаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGridView1.Visible = false;
            dataGridView2.Visible = false;
            dataGridView3.Visible = false;
            dataGridView4.Visible = false;
            dataGridView5.Visible = false;
            dataGridView6.Visible = false;
            dataGridView7.Visible = true;
        }

        private void корзинаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Корзина f9 = new Корзина();
            f9.Show();
        }

        private void добавитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Менеджеры f2 = new Менеджеры();
            f2.Show();
        }
    }
}
