﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ПК_сборка
{
    public partial class Регистрация : Form
    {
        public Регистрация()
        {
            InitializeComponent();
        }

        // Почта, с которой зарегистрировались (чтобы подставить её на форме входа)
        public string Почта
        {
            get { return this.textBox3.Text.Trim(); }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string почта = this.textBox3.Text.Trim();

                if (string.IsNullOrWhiteSpace(this.textBox1.Text) || почта == "" || this.textBox5.Text == "")
                {
                    MessageBox.Show("Заполните ФИО, почту и пароль.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // ФИО - только буквы (и пробелы между словами)
                string фио = this.textBox1.Text.Trim();
                if (!фио.All(c => char.IsLetter(c) || c == ' '))
                {
                    MessageBox.Show("ФИО должно содержать только буквы.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Номер телефона - только цифры (если указан)
                string телефон = this.textBox2.Text.Trim();
                if (телефон != "" && !телефон.All(char.IsDigit))
                {
                    MessageBox.Show("Номер телефона должен содержать только цифры.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Почта - должна содержать знак @
                if (!почта.Contains("@"))
                {
                    MessageBox.Show("Почта должна содержать знак @.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (this.textBox5.Text != this.textBox6.Text)
                {
                    MessageBox.Show("Пароли не совпадают.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                using (OleDbConnection conn = new OleDbConnection(Сессия.СтрокаПодключения))
                {
                    conn.Open();

                    using (OleDbCommand check = new OleDbCommand("SELECT COUNT(*) FROM Покупатели WHERE Почта = ?", conn))
                    {
                        check.Parameters.AddWithValue("Почта", почта);
                        if (Convert.ToInt32(check.ExecuteScalar()) > 0)
                        {
                            MessageBox.Show("Покупатель с такой почтой уже зарегистрирован.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                    }

                    using (OleDbCommand cmd = new OleDbCommand("INSERT INTO Покупатели (ФИО, Номер_Телефона, Почта, Адрес_доставки, Пароль) VALUES (?, ?, ?, ?, ?)", conn))
                    {
                        cmd.Parameters.AddWithValue("ФИО", фио);
                        cmd.Parameters.AddWithValue("Номер_Телефона", телефон == "" ? (object)DBNull.Value : телефон);
                        cmd.Parameters.AddWithValue("Почта", почта);
                        cmd.Parameters.AddWithValue("Адрес_доставки", string.IsNullOrWhiteSpace(this.textBox4.Text) ? (object)DBNull.Value : this.textBox4.Text);
                        cmd.Parameters.AddWithValue("Пароль", this.textBox5.Text);
                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Регистрация прошла успешно.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при сохранении: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
