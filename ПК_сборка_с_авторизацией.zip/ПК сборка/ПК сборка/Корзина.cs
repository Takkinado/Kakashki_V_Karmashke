﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ПК_сборка
{
    public partial class Корзина : Form
    {
        private Database31DataSet database31DataSet = new Database31DataSet();
        private Database31DataSetTableAdapters.КомплектующиеTableAdapter комплектующиеTableAdapter = new Database31DataSetTableAdapters.КомплектующиеTableAdapter();

        public Корзина()
        {
            InitializeComponent();
        }

        private void Корзина_Load(object sender, EventArgs e)
        {
            this.комплектующиеTableAdapter.Fill(this.database31DataSet.Комплектующие);
            this.dataGridView1.DataSource = this.database31DataSet.Комплектующие;
            this.dataGridView2.DataSource = Сессия.ПозицииКорзины;
            ОбновитьИтого();
        }

        private void ОбновитьИтого()
        {
            decimal итого = Сессия.ПозицииКорзины.Sum(p => p.Сумма);
            this.label3.Text = "итого: " + итого.ToString("N2");
        }

        // Добавить в корзину
        private void button1_Click(object sender, EventArgs e)
        {
            DataRowView строка = this.dataGridView1.CurrentRow == null ? null : this.dataGridView1.CurrentRow.DataBoundItem as DataRowView;
            if (строка == null)
            {
                MessageBox.Show("Выберите комплектующее в списке.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int id = Convert.ToInt32(строка["Id_Комплектующего"]);
            ПозицияКорзины позиция = Сессия.ПозицииКорзины.FirstOrDefault(p => p.Id_Комплектующего == id);

            if (позиция != null)
            {
                позиция.Количество++;
                Сессия.ПозицииКорзины.ResetBindings();
            }
            else
            {
                Сессия.ПозицииКорзины.Add(new ПозицияКорзины
                {
                    Id_Комплектующего = id,
                    Название_Детали = Convert.ToString(строка["Название_Детали"]),
                    Цена = строка["Цена"] == DBNull.Value ? 0m : Convert.ToDecimal(строка["Цена"]),
                    Количество = 1
                });
            }
            ОбновитьИтого();
        }

        // Удалить из корзины
        private void button2_Click(object sender, EventArgs e)
        {
            ПозицияКорзины позиция = this.dataGridView2.CurrentRow == null ? null : this.dataGridView2.CurrentRow.DataBoundItem as ПозицияКорзины;
            if (позиция == null)
            {
                MessageBox.Show("Выберите позицию в корзине.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            Сессия.ПозицииКорзины.Remove(позиция);
            ОбновитьИтого();
        }

        private static int Скаляр(OleDbConnection conn, string sql)
        {
            using (OleDbCommand cmd = new OleDbCommand(sql, conn))
            {
                object результат = cmd.ExecuteScalar();
                return (результат == null || результат == DBNull.Value) ? 0 : Convert.ToInt32(результат);
            }
        }

        // Оформить заказ
        private void button3_Click(object sender, EventArgs e)
        {
            if (Сессия.ПозицииКорзины.Count == 0)
            {
                MessageBox.Show("Корзина пуста.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                int оформлено = 0;
                decimal сумма = 0m;

                using (OleDbConnection conn = new OleDbConnection(Сессия.СтрокаПодключения))
                {
                    conn.Open();

                    int idМенеджера = Скаляр(conn, "SELECT MIN(Id_Менеджера) FROM Менеджеры");
                    int idСборщика = Скаляр(conn, "SELECT MIN(Id_Сборщика) FROM Сборщики");
                    int idДоставки = Скаляр(conn, "SELECT MIN(Id_Доставки) FROM [Служба Доставки]");
                    if (idМенеджера == 0 || idСборщика == 0 || idДоставки == 0)
                    {
                        MessageBox.Show("Для оформления заказа нужны записи в таблицах Менеджеры, Сборщики и Служба Доставки.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    int idКонфигурации = Math.Max(
                        Скаляр(conn, "SELECT MAX(ID_Конфигурации) FROM [Состав конфига]"),
                        Скаляр(conn, "SELECT MAX(ID_Конфигурации) FROM Заказы"));

                    using (OleDbTransaction транзакция = conn.BeginTransaction())
                    {
                        try
                        {
                            foreach (ПозицияКорзины p in Сессия.ПозицииКорзины)
                            {
                                idКонфигурации++;

                                using (OleDbCommand cmd = new OleDbCommand("INSERT INTO [Состав конфига] (ID_Конфигурации, ID_Комплектующего, Количество) VALUES (?, ?, ?)", conn, транзакция))
                                {
                                    cmd.Parameters.Add("ID_Конфигурации", OleDbType.Integer).Value = idКонфигурации;
                                    cmd.Parameters.Add("ID_Комплектующего", OleDbType.Integer).Value = p.Id_Комплектующего;
                                    cmd.Parameters.Add("Количество", OleDbType.Integer).Value = p.Количество;
                                    cmd.ExecuteNonQuery();
                                }

                                using (OleDbCommand cmd = new OleDbCommand("INSERT INTO Заказы (ID_Конфигурации, ID_Покупателя, ID_Менеджера, ID_Сборщика, ID_Доставки, Дата_создания, Итоговая_Стоимость, Статус) VALUES (?, ?, ?, ?, ?, ?, ?, ?)", conn, транзакция))
                                {
                                    cmd.Parameters.Add("ID_Конфигурации", OleDbType.Integer).Value = idКонфигурации;
                                    cmd.Parameters.Add("ID_Покупателя", OleDbType.Integer).Value = Сессия.ID_Покупателя;
                                    cmd.Parameters.Add("ID_Менеджера", OleDbType.Integer).Value = idМенеджера;
                                    cmd.Parameters.Add("ID_Сборщика", OleDbType.Integer).Value = idСборщика;
                                    cmd.Parameters.Add("ID_Доставки", OleDbType.Integer).Value = idДоставки;
                                    cmd.Parameters.Add("Дата_создания", OleDbType.Date).Value = DateTime.Now;
                                    cmd.Parameters.Add("Итоговая_Стоимость", OleDbType.Currency).Value = p.Сумма;
                                    cmd.Parameters.Add("Статус", OleDbType.VarWChar).Value = "Новый";
                                    cmd.ExecuteNonQuery();
                                }

                                оформлено++;
                                сумма += p.Сумма;
                            }
                            транзакция.Commit();
                        }
                        catch
                        {
                            транзакция.Rollback();
                            throw;
                        }
                    }
                }

                Сессия.ПозицииКорзины.Clear();
                ОбновитьИтого();

                MessageBox.Show($"Оформлено заказов: {оформлено}. Итого: {сумма:N2}", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                var mainForm = Application.OpenForms.OfType<Form1>().FirstOrDefault();
                if (mainForm != null) mainForm.RefreshAllTables();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при оформлении заказа: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
