﻿using System;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;

namespace ПК_сборка
{
    // Позиция в корзине
    public class ПозицияКорзины
    {
        public int Id_Комплектующего { get; set; }
        public string Название_Детали { get; set; }
        public decimal Цена { get; set; }
        public int Количество { get; set; }
        public decimal Сумма { get { return Цена * Количество; } }
    }

    // Данные текущего пользователя и корзина (общие для всех форм)
    public static class Сессия
    {
        public static int ID_Покупателя;
        public static string ФИО;
        public static bool ЭтоАдмин;
        public static readonly BindingList<ПозицияКорзины> ПозицииКорзины = new BindingList<ПозицияКорзины>();

        public static string СтрокаПодключения
        {
            get { return Properties.Settings.Default.Database31ConnectionString; }
        }

        // Добавляет в таблицу комплектующих столбец Количество и заполняет его из базы
        public static void ЗагрузитьОстатки(DataTable таблица)
        {
            if (!таблица.Columns.Contains("Количество"))
                таблица.Columns.Add("Количество", typeof(int));

            using (OleDbConnection conn = new OleDbConnection(СтрокаПодключения))
            using (OleDbCommand cmd = new OleDbCommand("SELECT Id_Комплектующего, Количество FROM Комплектующие", conn))
            {
                conn.Open();
                using (OleDbDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        DataRow[] строки = таблица.Select("Id_Комплектующего = " + Convert.ToInt32(reader[0]));
                        if (строки.Length > 0)
                            строки[0]["Количество"] = reader[1] == DBNull.Value ? 0 : Convert.ToInt32(reader[1]);
                    }
                }
            }
            таблица.AcceptChanges();
        }

        // В таблице Покупатели нужен столбец Пароль - если его нет, добавляем
        public static void ПодготовитьБазу()
        {
            try
            {
                using (OleDbConnection conn = new OleDbConnection(СтрокаПодключения))
                {
                    conn.Open();
                    var колонки = conn.GetSchema("Columns", new string[] { null, null, "Покупатели", "Пароль" });
                    if (колонки.Rows.Count == 0)
                    {
                        using (OleDbCommand cmd = new OleDbCommand("ALTER TABLE Покупатели ADD COLUMN Пароль TEXT(50)", conn))
                        {
                            cmd.ExecuteNonQuery();
                        }
                    }

                    // В «Составе конфига» один заказ должен содержать несколько позиций:
                    // ключ - пара (ID_Конфигурации, ID_Комплектующего), а не один ID_Конфигурации
                    var ключ = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Primary_Keys, new object[] { null, null, "Состав конфига" });
                    if (ключ.Rows.Count == 1)
                    {
                        string имяКлюча = Convert.ToString(ключ.Rows[0]["PK_NAME"]);
                        var связи = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Foreign_Keys, new object[] { null, null, "Состав конфига", null, null, null });
                        foreach (DataRow связь in связи.Rows)
                        {
                            if (Convert.ToString(связь["PK_TABLE_NAME"]) != "Состав конфига") continue;
                            using (OleDbCommand cmd = new OleDbCommand("ALTER TABLE [" + связь["FK_TABLE_NAME"] + "] DROP CONSTRAINT [" + связь["FK_NAME"] + "]", conn))
                            {
                                cmd.ExecuteNonQuery();
                            }
                        }
                        using (OleDbCommand cmd = new OleDbCommand("ALTER TABLE [Состав конфига] DROP CONSTRAINT [" + имяКлюча + "]", conn))
                        {
                            cmd.ExecuteNonQuery();
                        }
                        using (OleDbCommand cmd = new OleDbCommand("ALTER TABLE [Состав конфига] ADD CONSTRAINT PK_Состав_конфига PRIMARY KEY (ID_Конфигурации, ID_Комплектующего)", conn))
                        {
                            cmd.ExecuteNonQuery();
                        }
                    }

                    // В таблице Комплектующие нужен столбец Количество (остаток на складе)
                    var остаток = conn.GetSchema("Columns", new string[] { null, null, "Комплектующие", "Количество" });
                    if (остаток.Rows.Count == 0)
                    {
                        using (OleDbCommand cmd = new OleDbCommand("ALTER TABLE Комплектующие ADD COLUMN Количество LONG", conn))
                        {
                            cmd.ExecuteNonQuery();
                        }
                        // для уже существующих комплектующих задаём начальный остаток
                        using (OleDbCommand cmd = new OleDbCommand("UPDATE Комплектующие SET Количество = 10", conn))
                        {
                            cmd.ExecuteNonQuery();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при подготовке базы: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
