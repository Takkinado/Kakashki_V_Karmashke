﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ПК_сборка
{
    internal static class Program
    {
        /// <summary>
        /// Главная точка входа для приложения.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Сессия.ПодготовитьБазу();
            using (Вход вход = new Вход())
            {
                if (вход.ShowDialog() != DialogResult.OK) return;
            }
            Application.Run(new Form1());
        }
    }
}
