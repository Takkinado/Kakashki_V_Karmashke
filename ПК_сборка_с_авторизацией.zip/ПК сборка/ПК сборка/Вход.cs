﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ПК_сборка
{
    public partial class Вход : Form
    {
        public Вход()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string почта = this.textBox1.Text.Trim();
            string пароль = this.textBox2.Text;

            if (почта == "" || пароль == "")
            {
                MessageBox.Show("Введите почту и пароль.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Вход для администратора
            if (почта == "komp" && пароль == "1234")
            {
                Сессия.ЭтоАдмин = true;
                Сессия.ID_Покупателя = 0;
                Сессия.ФИО = "Администратор";
                this.DialogResult = DialogResult.OK;
                return;
            }

            try
            {
                using (OleDbConnection conn = new OleDbConnection(Сессия.СтрокаПодключения))
                using (OleDbCommand cmd = new OleDbCommand("SELECT ID_Покупателя, ФИО, Пароль FROM Покупатели WHERE Почта = ?", conn))
                {
                    cmd.Parameters.AddWithValue("Почта", почта);
                    conn.Open();
                    using (OleDbDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string сохранённый = Convert.ToString(reader["Пароль"]);
                            if (сохранённый != "" && сохранённый == пароль)
                            {
                                Сессия.ЭтоАдмин = false;
                                Сессия.ID_Покупателя = Convert.ToInt32(reader["ID_Покупателя"]);
                                Сессия.ФИО = Convert.ToString(reader["ФИО"]);
                                this.DialogResult = DialogResult.OK;
                                return;
                            }
                        }
                    }
                }
                MessageBox.Show("Неверная почта или пароль.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при входе: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (Регистрация f = new Регистрация())
            {
                if (f.ShowDialog() == DialogResult.OK)
                {
                    this.textBox1.Text = f.Почта;
                    this.textBox2.Clear();
                    this.textBox2.Focus();
                }
            }
        }
    }
}
