﻿using System;
using System.ComponentModel;
using System.Data.OleDb;
using System.Windows.Forms;

namespace ПК_сборка
{
    // Позиция в корзине
    public class ПозицияКорзины
    {
        public int Id_Комплектующего { get; set; }
        public string Название_Детали { get; set; }
        public decimal Цена { get; set; }
        public int Количество { get; set; }
        public decimal Сумма { get { return Цена * Количество; } }
    }

    // Данные текущего пользователя и корзина (общие для всех форм)
    public static class Сессия
    {
        public static int ID_Покупателя;
        public static string ФИО;
        public static bool ЭтоАдмин;
        public static readonly BindingList<ПозицияКорзины> ПозицииКорзины = new BindingList<ПозицияКорзины>();

        public static string СтрокаПодключения
        {
            get { return Properties.Settings.Default.Database31ConnectionString; }
        }

        // В таблице Покупатели нужен столбец Пароль - если его нет, добавляем
        public static void ПодготовитьБазу()
        {
            try
            {
                using (OleDbConnection conn = new OleDbConnection(СтрокаПодключения))
                {
                    conn.Open();
                    var колонки = conn.GetSchema("Columns", new string[] { null, null, "Покупатели", "Пароль" });
                    if (колонки.Rows.Count == 0)
                    {
                        using (OleDbCommand cmd = new OleDbCommand("ALTER TABLE Покупатели ADD COLUMN Пароль TEXT(50)", conn))
                        {
                            cmd.ExecuteNonQuery();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при подготовке базы: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
